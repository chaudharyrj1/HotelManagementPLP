package com.cg.hm.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.hm.dto.BookingDetails;
import com.cg.hm.dto.Hotels;
import com.cg.hm.dto.RoomDetails;
import com.cg.hm.dto.UserDetails;
import com.cg.hm.exception.HotelManagementException;


public interface IHotelDao {
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();

	public UserDetails userLogin(String userName) throws HotelManagementException;
	
	public void addUser(UserDetails userDetails);
	
	public List<Hotels> viewAllHotels();
	
	public List<BookingDetails> viewBookingDetailsFromDate(LocalDate date);
	
	public List<Hotels> searchHotels(String city,int minPrice,int maxPrice,int rating); 	
	
	public List<String> viewGuestListSpecificHotels(String hotellId); 	
	
	public List<BookingDetails> viewBookingSpecificHotel(String hotelId);	

	public void addHotel(Hotels hotelDetails);
	
	public void deleteHotel(String hId);
	
	public void deleteRoom(String roomId);
	
	public void updateHotel(Hotels hotelDetails);
	
	public void addRoom(RoomDetails rumDetails);
	
	public void updateRoom(RoomDetails rumDetails);

	public void updateTableBeforeBooking(BookingDetails bkDetailsObj); 

	public void update(BookingDetails bkDetails); 

	public RoomDetails checkAvailability(BookingDetails bkDetails); 

	public void bookHotel(BookingDetails bkDetails); 
	public int getAmountToBePaid(BookingDetails bkDetails) ;

	RoomDetails getStatus(RoomDetails rumDetails);

	
}
