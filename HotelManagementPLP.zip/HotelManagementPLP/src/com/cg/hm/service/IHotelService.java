package com.cg.hm.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.hm.dto.BookingDetails;
import com.cg.hm.dto.Hotels;
import com.cg.hm.dto.RoomDetails;
import com.cg.hm.dto.UserDetails;
import com.cg.hm.exception.HotelManagementException;



public interface IHotelService {

	public boolean adminLogin(String userName,String password); //will verify username and password of admin and return true or false.(these values are hardcoded in service class.)

	public int userLogin(String userName,String Password) throws HotelManagementException; //this will verify login details of user and return status(0/1) from dao layer.

	public void addUser(UserDetails userDetails);
	
	public void addHotel(Hotels hotel);
	
	public void updateHotel(Hotels hotel);
	
	public void deleteHotel(String hotelID);
	
	public void addRoom(RoomDetails rDetails);
	
	public void deleteRoom(String roomID);
	
	public void updateRoom(RoomDetails rDetails);
	
	public List<Hotels> viewAllHotels(); //it will display all hotels from table HOTELS.

	public List<BookingDetails> viewBookingSpecificHotel(String hotelId);
 
	public List<String> viewGuestListSpecificHotels(String hotellId); 

	public List<BookingDetails> viewBookingDetailsFromDate(LocalDate date); 

	public List<Hotels> searchHotels(String city, int minPrice,int maxPrice,
			int rating); 

	public int bookingStatus(); 

	int getAmountToBePaid(BookingDetails bkDetails);

	int bookHotel(BookingDetails bkDetails);

	public RoomDetails getStatus(RoomDetails rumDetails);

	

}
