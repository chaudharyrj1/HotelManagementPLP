package com.cg.hm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hm.dto.Hotels;
import com.cg.hm.dto.RoomDetails;
import com.cg.hm.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	IHotelService hotelService;

	@RequestMapping("/home.htm")
	public String redirectToHome()
	{
		return "Home";
	}
	@RequestMapping("/login.htm")
	public String login()
	{
		return "Login";
	}

	@RequestMapping("/checkLogin.htm")
	public String checkLogin(@RequestParam("id") String id,@RequestParam("password") String password,Model model)
	{
		if("System".equals(id)&&"Capgemini123".equals(password))
			return "Admin";
		else
		{
			model.addAttribute("message","Invalid Id or Password!!!");
			return "Login";
		}
	}

	@RequestMapping("/addHotel.htm")
	public String addHotel(Model model)
	{
		Hotels hotel= new Hotels();
		model.addAttribute("hotel", hotel);
		return "addHotel";
	}

	@RequestMapping(value="/addHotelImpl.htm",method=RequestMethod.POST)
	public String addHotelImpl(@ModelAttribute("hotel") Hotels hotel,Model model)
	{
		System.out.println(hotel.getId());
		
		hotel.setHotelId(String.valueOf(hotel.getId()));
		hotelService.addHotel(hotel);
		model.addAttribute("message", "Hotel Added Successfully!!!");
		return "Admin";
	}
	/*
	@RequestMapping(value="/addHotelImpl.htm",method=RequestMethod.POST)
	public String addHotelImpl(@ModelAttribute("hotel") Hotels hotel,Model model)
	{
		hotel.setHotelId(String.valueOf(hotel.getId()));
		hotelService.addHotel(hotel);
		model.addAttribute("message", "Hotel Added Successfully!!!");
		return "Admin";
	}*/
	
	
	@RequestMapping("/addRoom.htm")
	public String addRoom(Model model)
	{
		RoomDetails room=new RoomDetails();
		model.addAttribute("room", room);
		model.addAttribute("roomTypeList", new String[]{"Select","Standard non A/C room","Standard A/C room","Executive A/C room", "Deluxe A/C room"});
		return "addRoom";
	}
	
	@RequestMapping(value="/addRoomImpl.htm",method=RequestMethod.POST)
	public String addRoomImpl(@ModelAttribute("room") RoomDetails room,Model model)
	{
		room.setRoomId(String.valueOf(room.getId()));
		hotelService.addRoom(room);
		model.addAttribute("message", "Room Added Successfully!!!");
		return "Admin";
	}
}
